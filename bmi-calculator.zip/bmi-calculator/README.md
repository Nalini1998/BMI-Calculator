# BMI Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini1998/pen/RwEodjq/180b88e129eb14d4eec05d9ef25ca928](https://codepen.io/Nalini1998/pen/RwEodjq/180b88e129eb14d4eec05d9ef25ca928).

Body mass index (BMI) is a measure of body fat based on height and weight that applies to adult men and women. The current UI is dark theme and background of result changes as per the bmi index.  For example: If underweight it will turn blue, for normal green, for overweight orange and for obese red.